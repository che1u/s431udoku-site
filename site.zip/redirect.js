location.replace('/ru/');
