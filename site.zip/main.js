'use strict';
const language = document.querySelector('#language');
if (language) language.addEventListener('change', () => { location.href = language.value; });
const form = document.querySelector('#deletion');
if (form) {
  let key = null, previous = null;
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const body = Object.fromEntries(new FormData(form));
    const fingerprint = JSON.stringify(body);
    if (fingerprint !== previous) { key = crypto.randomUUID(); previous = fingerprint; }
    const button = form.querySelector('button');
    const status = document.querySelector('#form-status');
    button.disabled = true; status.textContent = '';
    try {
      const response = await fetch('https://api-sudoku.431u.ru:9443/v1/deletion-requests', {
        method:'POST', headers:{'Content-Type':'application/json','Idempotency-Key':key},
        body:fingerprint, signal:AbortSignal.timeout(15000), credentials:'omit'
      });
      if (!response.ok || !(await response.json()).received) throw new Error('Request failed');
      status.textContent = form.dataset.success; form.reset(); key = null; previous = null;
    } catch (_) { status.textContent = form.dataset.failure; }
    finally { button.disabled = false; }
  });
}
